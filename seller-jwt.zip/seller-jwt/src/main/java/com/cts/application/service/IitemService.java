package com.cts.application.service;

import java.util.List
;
import com.cts.application.model.ItemsEntity;



public interface IitemService {

	String addItem(int sid, ItemsEntity iItem);

	List<ItemsEntity> getAllitem();

	void deleteById(Integer sId);

	void deleteAllitem();

	String updateItem(int iid, ItemsEntity iitem1);

	List<ItemsEntity> getitembyname(String itemName);

	String updateItem1(int iid, ItemsEntity iitem1);


	
	
	
	
	

	

}
