package com.cts.application.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class SubCategoryEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int subcategoryId;
	@ManyToOne
	@Autowired
	@JoinColumn(name="categoryId")
	private CategoryEntity categoryId;
	
	private String subcategoryName;
	

	
	//private CategoryEntity categoryId;
	private String briefDetails;
	
	
	
	
	public SubCategoryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public String getSubcategoryName() {
		return subcategoryName;
	}
	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}
	
	public String getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}
	public SubCategoryEntity(int subcategoryId, String subcategoryName, CategoryEntity categoryId, String briefDetails) {
		super();
		this.subcategoryId = subcategoryId;
		this.subcategoryName = subcategoryName;
		//this.categoryId = categoryId;
		this.briefDetails = briefDetails;
	}
	@Override
	public String toString() {
		return "SubCategoryEntity [subcategoryId=" + subcategoryId + ", subcategoryName=" + subcategoryName
				+  ", briefDetails=" + briefDetails + "]";
	}
	
	
	
}
