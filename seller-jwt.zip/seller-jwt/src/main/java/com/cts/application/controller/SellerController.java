package com.cts.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.application.model.Seller;
import com.cts.application.service.ISellerService;
@CrossOrigin("*")
@RestController
public class SellerController {
	
	@Autowired
	private ISellerService sellerservice;
	
	@GetMapping("/getAll")
	public List<Seller> getAll(){
		
		return sellerservice.getAllSellers();
	}
	
	@PostMapping(value="/addseller",produces = "application/json")
	
	public Seller addseller(@RequestBody Seller seller) {
		
		return sellerservice.add(seller);
	}
	


}
