package com.cts.application.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cts.application.model.ItemsEntity;



public interface ItemDao extends JpaRepository<ItemsEntity, Integer> {
	@Transactional
	@Modifying
	@Query(value ="DELETE FROM ItemsEntity WHERE itemsentity.seller_id = :sellerId"
	,nativeQuery = true)
	public void emptyItem(@Param("sellerId")Integer sellerId);

	@Query(value="SELECT * FROM ItemsEntity item WHERE item.seller_id = :sellerId"
			,nativeQuery = true)
	public List<ItemsEntity> getAllItems(@Param("sellerId")Integer sellerId);


	@Query(value="FROM ItemsEntity where itemName like %:itemName%")
	public List<ItemsEntity> finditem(@Param("itemName") String itemName);

}


