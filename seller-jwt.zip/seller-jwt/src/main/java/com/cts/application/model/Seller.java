package com.cts.application.model;




import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Seller implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int sellerId;
	private String userName;
	private String password;
	private String companyname;
	private String gstin;
	private String briefaboutcompany;
	private String postal_address;
	private String website;
	private String emailId;
	private int contactnumber;
	
	

	
	public Seller() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getsellerId() {
		return sellerId;
	}
	public void setsellerId(int sellerId) {
		this.sellerId =sellerId;
	}
	public String getuserName() {
		return userName;
	}
	public void setuserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
	this.gstin = gstin;
	}
	public String getBriefaboutcompany() {
		return briefaboutcompany;
	}
	public void setBriefaboutcompany(String briefaboutcompany) {
		this.briefaboutcompany = briefaboutcompany;
	}
	public String getPostal_address() {
		return postal_address;
	}
	public void setPostal_address(String postal_address) {
		this.postal_address = postal_address;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(int contactnumber) {
		this.contactnumber = contactnumber;
	}
	public Seller(int sellerId, String userName,String gstin, String password, String companyname, String briefaboutcompany,
			String postal_address, String website, String emailId, int contactnumber) {
		
		this.sellerId =sellerId;
		this.userName = userName;
		this.password = password;
		this.companyname = companyname;
		this.gstin = gstin;
		this.briefaboutcompany = briefaboutcompany;
		this.postal_address = postal_address;
		this.website = website;
		this.emailId = emailId;
		this.contactnumber = contactnumber;
	}

	
}
