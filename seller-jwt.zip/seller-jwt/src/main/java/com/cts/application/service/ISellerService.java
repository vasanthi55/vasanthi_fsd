package com.cts.application.service;

import java.util.List;


import com.cts.application.model.Seller;


public interface ISellerService {

List<Seller> getAllSellers();
	
	Seller add(Seller seller);
	

}
