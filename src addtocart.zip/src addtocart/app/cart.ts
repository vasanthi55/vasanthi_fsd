export class Cart {
 
 cartId:number;
 itemId:number;
 quantity:number;
 price:number;
 description:String;



}