import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Cart } from './cart';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:8385/items';



  constructor(private http: HttpClient) { }

  getItems(itemname: string) : Observable<any> {
    console.log(itemname);

    return this.http.get(`${this.baseUrl}/getitems/${itemname}`);
  }
  addToCart(cart:Cart):Observable<any> {
return this.http.post(`http://localhost:8386/cart/addToCart/1`,cart);


  }

displayCartItems() : Observable<any>{

return this.http.get(`http://localhost:8386/cart/1/getAll`);

}

}


