export class InfoModels
{
    id: number;
    firstName:string;
    lastName: string;
    age:number;
    email:string;
    phone:number;
    addr:string;
    city:string;
    package:string;
    trainerpref:string;
}