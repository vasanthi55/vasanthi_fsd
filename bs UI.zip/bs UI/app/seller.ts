export class Seller{
    sellerName: String;
    password:number;
   companyname: String;
   gstin: String;
   briefaboutcompany: String;
   postal_address: String;
   website: String;
   emailId: String;
    contactnumber:number;
  
     
  }
  
  
  
  
  
  