 package com.cts.application.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.cts.application.entity.BuyerEntity;
import com.cts.application.entity.ShoppingCartEntity;


public interface IBuyerService {

	List<BuyerEntity> getAllBuyers();
	BuyerEntity add(BuyerEntity buyer);

	
	

}
