package com.cts.entity.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.entity.ShoppingCartEntity;

public interface CartDao extends JpaRepository<ShoppingCartEntity, Integer> {

	
	



	
}
