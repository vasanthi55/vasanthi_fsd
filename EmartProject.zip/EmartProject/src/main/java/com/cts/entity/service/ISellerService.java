package com.cts.entity.service;

import java.util.List;

import com.cts.entity.BuyerEntity;
import com.cts.entity.Seller;
import com.cts.entity.ShoppingCartEntity;

public interface ISellerService {

	List<Seller> getAllSellers();
	Seller add(Seller seller);

	
	

}
