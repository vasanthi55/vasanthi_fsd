package com.cts.entity.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.BuyerEntity;
import com.cts.entity.Seller;
import com.cts.entity.ShoppingCartEntity;
import com.cts.entity.dao.BuyerDao;
import com.cts.entity.dao.SellerDao;
@Service
public class SellerService implements ISellerService {
	
	@Autowired
	private SellerDao sdao;

	
	@Override
	public List<Seller> getAllSellers() {
		return sdao.findAll();
	}

    
	@Override
	public Seller add(Seller seller) {
		
	return sdao.save(seller);
	}
	
	

}
