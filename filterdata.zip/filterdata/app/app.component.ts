import { Component } from '@angular/core';
import {FilterData} from './filterData';
@Component({
  selector: 'app-root',
	template: `
	<input type="text" #filter (keyup)="0">
	<table border=1>
	<tr *ngFor="let point of (points | filterData: filter.value)">
	<td>{{point}}
	</td></tr>
	    `
})

export class AppComponent {
	points: string[] = [
		 'ammu',
		 'charu',
		 'srav',
		 'divya' 
	];
}