package com.cts.application.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.application.entity.BuyerEntity;
@Repository
public interface BuyerDao extends JpaRepository<BuyerEntity,Integer>{
	
}
