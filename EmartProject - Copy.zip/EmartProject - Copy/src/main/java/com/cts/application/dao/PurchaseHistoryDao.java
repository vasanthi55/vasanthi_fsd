package com.cts.application.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.application.entity.PurchaseHistoryEntity;
import com.cts.application.entity.ShoppingCartEntity;

@Repository

public interface PurchaseHistoryDao extends JpaRepository<ShoppingCartEntity, Integer>{

	void save(PurchaseHistoryEntity phistory);

}
