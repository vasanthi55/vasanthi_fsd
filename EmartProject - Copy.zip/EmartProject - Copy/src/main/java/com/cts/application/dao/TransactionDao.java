package com.cts.application.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.application.entity.ShoppingCartEntity;
import com.cts.application.entity.TransactionEntity;
@Repository

 public interface TransactionDao extends JpaRepository<ShoppingCartEntity, Integer>{

	void save(TransactionEntity transac);

}
