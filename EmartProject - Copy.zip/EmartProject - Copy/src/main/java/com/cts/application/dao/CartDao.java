package com.cts.application.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cts.application.entity.ShoppingCartEntity;

public interface CartDao extends JpaRepository<ShoppingCartEntity, Integer> {
@Transactional
@Modifying
	@Query(value ="DELETE FROM shoppingcartentity WHERE shoppingcartentity.buyer_id = :buyerId"
			,nativeQuery = true)
	public void emptyCart(@Param("buyerId")Integer buyerId);
	
	@Query(value="SELECT * FROM shoppingcartentity cart WHERE cart.buyer_id = :buyerId"
			,nativeQuery = true)
	public List<ShoppingCartEntity> getAllCArtItems(@Param("buyerId")Integer buyerId);

	public List<ShoppingCartEntity> byid(int buyerid);
	



	
}
