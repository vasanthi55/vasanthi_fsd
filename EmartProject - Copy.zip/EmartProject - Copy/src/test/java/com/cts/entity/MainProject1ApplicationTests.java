package com.cts.entity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
