package com.cts.application.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.application.dao.SellerDao;
import com.cts.application.entity.Seller;

@Service
public class SellerService implements ISellerService {
	
	@Autowired
	private SellerDao sdao;

	
	@Override
	public List<Seller> getAllSellers() {
		return sdao.findAll();
	}

    
	@Override
	public Seller add(Seller seller) {
		
	return sdao.save(seller);
	}
	
	

}
