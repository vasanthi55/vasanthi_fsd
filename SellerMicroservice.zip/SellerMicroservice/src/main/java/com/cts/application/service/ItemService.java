package com.cts.application.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.application.dao.ItemDao;
import com.cts.application.dao.SellerDao;
import com.cts.application.entity.ItemsEntity;
import com.cts.application.entity.Seller;

@Service
public class ItemService implements IitemService {
@Autowired
private SellerDao sdao;

@Autowired
private ItemDao idao;

@Override
public String addItem(int sid, ItemsEntity iItem) {
   Seller ir=sdao.getOne(sid);
iItem.setSeller(ir);  
System.out.println(iItem);
idao.save(iItem);
return "Return item";
}





@Override
public List<ItemsEntity> getAllitem() {

return idao.findAll();
}




@Override
public void deleteById(Integer sId) {
Optional<ItemsEntity> buyer = idao.findById(sId);

if(buyer.isPresent()) {
idao.deleteById(sId);
}

}



@Override
public void deleteAllitem() {
idao.deleteAll();

}



@Override
public String updateItem(int iid, ItemsEntity iitem1)
{

ItemsEntity update=idao.getOne(iid);

int stockNumber=iitem1.getStockNumber();
float tprice=iitem1.getPrice();
String description=iitem1.getDescription();
String itemName=iitem1.getItemName();
String remarks=iitem1.getRemarks();
update.setStockNumber(stockNumber);
update.setPrice(tprice);
update.setDescription(description);
update.setItemName(itemName);
update.setRemarks(remarks);
System.out.println(update);
idao.save(update);
return "items updated";
}


	

@Override
public List<ItemsEntity> getitembyname(String itemname) {

return idao.finditem(itemname);
}






}
