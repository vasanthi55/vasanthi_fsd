package com.cts.application.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.application.entity.Seller;


public interface ISellerService {

	List<Seller> getAllSellers();
	
	Seller add(Seller seller);

	
	

}
