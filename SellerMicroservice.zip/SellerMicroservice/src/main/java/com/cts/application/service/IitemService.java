package com.cts.application.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cts.application.entity.ItemsEntity;


public interface IitemService {

	String addItem(int sid, ItemsEntity iItem);

	List<ItemsEntity> getAllitem();

	void deleteById(Integer sId);

	void deleteAllitem();

	String updateItem(int iid, ItemsEntity iitem1);

	List<ItemsEntity> getitembyname(String itemName);


	
	
	
	
	

	

}
