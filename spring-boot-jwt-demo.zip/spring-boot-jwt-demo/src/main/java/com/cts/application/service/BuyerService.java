 package com.cts.application.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.application.dao.BuyerDao;
import com.cts.application.model.BuyerEntity;



@Service
public class BuyerService implements IBuyerService,UserDetailsService {
	
	@Autowired
	private BuyerDao bdao;
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	
	@Override
	public List<BuyerEntity> getAllBuyers() {
		return bdao.findAll();
	}

    
	@Override
	public BuyerEntity add(BuyerEntity buyer) {
		buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		return bdao.save(buyer);
	}

	

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerEntity buyer = bdao.findByuserName(username);
		if(buyer == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getUserName(), buyer.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_BUYER"));
	}


	public BuyerEntity findone(String username) {
		// TODO Auto-generated method stub
		return bdao.findByuserName(username);
	}
	

}
