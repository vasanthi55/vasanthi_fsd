  package com.cts.application.model;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class ShoppingCartEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartId;
	
	//@OneToMany//(cascade = CascadeType.ALL, mappedBy = "shoppingCart")
	//private List<ItemsEntity> itemsEntity;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
	private BuyerEntity buyerId;
	private int quantity;
	private float price;
	private String description;
	private int itemId;
	public int getCartId() {
		return cartId;
	}
	
	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public BuyerEntity getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(BuyerEntity buyerId) {
		this.buyerId = buyerId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public ShoppingCartEntity(int cartId, BuyerEntity buyerId, int quantity, float price, String description,
			int itemId) {
		super();
		this.cartId = cartId;
		this.buyerId = buyerId;
		this.quantity = quantity;
		this.price = price;
		this.description = description;
		this.itemId = itemId;
	}

	public ShoppingCartEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ShoppingCartEntity [cartId=" + cartId + ", buyerId=" + buyerId + ", quantity=" + quantity + ", price="
				+ price + ", description=" + description + ", itemId=" + itemId + "]";
	}

	
	
	
	
	
	

	
}
