package com.cts.application.model;

public class AuthToken {

    private String token;
    private String username;
    private Integer buyerId;
    
    public AuthToken() {
    	}

    
	public AuthToken(String token, String username, Integer buyerId) {
		super();
		this.token = token;
		this.username = username;
		this.buyerId = buyerId;
	}


	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	

	public Integer getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(Integer buyerId) {
		this.buyerId = buyerId;
	}

	@Override
	public String toString() {
		return "AuthToken [token=" + token + ", username=" + username + ", buyerId="
				+ buyerId + "]";
	}

    }
    

   

   