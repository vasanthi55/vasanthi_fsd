package com.cts.application.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.application.model.PurchaseHistoryEntity;



public interface PurchaseHistoryDao extends JpaRepository<PurchaseHistoryEntity, Integer> {

	

}
