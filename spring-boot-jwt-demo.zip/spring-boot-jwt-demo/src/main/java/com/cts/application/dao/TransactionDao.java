package com.cts.application.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.application.model.TransactionEntity;



public interface TransactionDao extends JpaRepository<TransactionEntity, Integer> {

	

}
