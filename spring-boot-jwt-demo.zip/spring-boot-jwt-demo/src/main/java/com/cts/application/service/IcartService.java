package com.cts.application.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cts.application.model.ShoppingCartEntity;
import com.cts.application.model.TransactionEntity;




public interface IcartService {

	List<ShoppingCartEntity> getAllCart();

	Optional<ShoppingCartEntity> getPersonById(int pid);

	ShoppingCartEntity addCart(ShoppingCartEntity cItem);

	void deleteById(Integer cId);

	void deleteAllCart();

	String addCart(int bid, ShoppingCartEntity cItem);

	String updateCart(int cid, ShoppingCartEntity scart1);

	String checkout(TransactionEntity transac, int buyerid);
	
	

	

	
	
	
	
	

	

}
