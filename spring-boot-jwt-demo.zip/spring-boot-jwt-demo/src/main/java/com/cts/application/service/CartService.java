package com.cts.application.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.application.dao.BuyerDao;
import com.cts.application.dao.CartDao;
import com.cts.application.dao.PurchaseHistoryDao;
import com.cts.application.dao.TransactionDao;
import com.cts.application.model.BuyerEntity;
import com.cts.application.model.PurchaseHistoryEntity;
import com.cts.application.model.ShoppingCartEntity;
import com.cts.application.model.TransactionEntity;


@Service
public class CartService implements IcartService {
	@Autowired
	private BuyerDao bdao;
	
	@Autowired
	private CartDao cdao;
	
	@Autowired
	private TransactionDao tdao;
	
	@Autowired
	private PurchaseHistoryDao pdao;
	
	
	@Override
	public String addCart(int bid, ShoppingCartEntity cItem) {
		BuyerEntity br=bdao.getOne(bid);
		cItem.setBuyerId(br);  
		System.out.println(cItem);
		 cdao.save(cItem);
		 return "Return buyer";
	}

	
	
	
	
	@Override
public List<ShoppingCartEntity> getAllCart() {
		
		return cdao.findAll();
	}
	
	
	@Override
	public Optional<ShoppingCartEntity> getPersonById(int id) {
	
		return cdao.findById(id);
	}	
	
	/*
	 * @Override public ShoppingCartEntity addCart(ShoppingCartEntity cItem) {
	 * 
	 * return cdao.save(cItem);
	 * 
	 * 
	 * }
	 */
	@Override
	public void deleteById(Integer cId) {
		Optional<ShoppingCartEntity> buyer = cdao.findById(cId);
		
		if(buyer.isPresent()) {
			cdao.deleteById(cId);
		}
		
	}

	
	
	@Override
	public void deleteAllCart() {
		cdao.deleteAll();
		
	}


	@Override
	public ShoppingCartEntity addCart(ShoppingCartEntity cItem) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String updateCart(int cid, ShoppingCartEntity scart1) 
	{
		
		ShoppingCartEntity update=cdao.getOne(cid);
		
		int quantity=scart1.getQuantity();
		float tprice=scart1.getPrice();
		String discription=scart1.getDescription();
		update.setQuantity(quantity);
		update.setPrice(tprice);
		update.setDescription(discription);
		System.out.println(update);
		cdao.save(update);
		return "\"Cart item updated\"";
	}

	@Override
	public String checkout(TransactionEntity transac, int buyerid) {
		BuyerEntity buyer=bdao.getOne(buyerid);
		System.out.println(buyer);
		transac.setUser(buyer);
		System.out.println(transac);
		tdao.save(transac);
		List<ShoppingCartEntity> scart1=cdao.byid(buyerid);
		for(int i=0;i<scart1.size();i++)
		{
			PurchaseHistoryEntity phistory=new PurchaseHistoryEntity();
			ShoppingCartEntity scartitems=scart1.get(i);
			int size=scartitems.getQuantity();
			phistory.setNumberOfItems(size);
			phistory.setUser(buyer);
			System.out.println(phistory);
			cdao.deleteById(scartitems.getCartId());
			pdao.save(phistory);
			
		}
		
		return "Transaction completed";
	}

	


	

	

	
	
	

}
