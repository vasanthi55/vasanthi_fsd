package com.cts.application.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.application.model.ShoppingCartEntity;
import com.cts.application.model.TransactionEntity;
import com.cts.application.service.IcartService;

@CrossOrigin("*")
@RestController
@RequestMapping("/cart")
public class CartController {
		

		@Autowired
		private IcartService icart;
	
	@GetMapping("/{bid}/getAll")
	public List<ShoppingCartEntity> getAll(){
		
		return icart.getAllCart();
	}
	

	
	@PostMapping("addToCart/{bid}")
			public String addCart(@PathVariable("bid")int bid, @RequestBody ShoppingCartEntity cItem) {
		return icart.addCart(bid,cItem);
	}
	
	
	@DeleteMapping("deleteById/{cid}")
	public void deleteById(@PathVariable("cid") Integer cId) {
		
		icart.deleteById(cId);
		
	}
	

	@DeleteMapping("/deleteAllCart/{bid}")
	
	public void deleteAllCart() {
		
		icart.deleteAllCart();
		
	}
	
	
	@PutMapping("/updatecart/{cid}")
	
	
	public String updateCart(@PathVariable("cid") int cid,@RequestBody ShoppingCartEntity scart1)
	{
		return icart.updateCart(cid,scart1);
	}
	
	//checkout using buyerId
		@PostMapping("/checkout/{bid}")
		public String checkout(@RequestBody TransactionEntity transac,@PathVariable("bid") int buyerid){
			return icart.checkout(transac,buyerid);
		}
	
	
}
