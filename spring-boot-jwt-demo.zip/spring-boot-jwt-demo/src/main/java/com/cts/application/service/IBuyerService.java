package com.cts.application.service;

import java.util.List;

import com.cts.application.model.BuyerEntity;

public interface IBuyerService {

	List<BuyerEntity> getAllBuyers();
	BuyerEntity add(BuyerEntity buyer);

	
	

}
