 package com.cts.application.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.cts.application.model.BuyerEntity;


public interface IBuyerService {

	List<BuyerEntity> getAllBuyers();
	BuyerEntity add(BuyerEntity buyer);
	 BuyerEntity findone(String userName);

	
	

}
