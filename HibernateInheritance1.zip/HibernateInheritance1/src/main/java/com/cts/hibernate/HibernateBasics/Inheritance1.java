package com.cts.hibernate.HibernateBasics;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Account;
import com.cts.hibernate.model.DematAccount;
import com.cts.hibernate.model.SavingsAccount;

public class Inheritance1 {
	public static void main(String args[]) {

		Configuration configuration=new Configuration().configure();
		SessionFactory sf=configuration.buildSessionFactory();
		Session session=sf.openSession();
		
		Account ac=new Account();
		ac.setAccNum(1013);
		ac.setName("harika1");
		
		DematAccount dma=new DematAccount();
		dma.setAccNum(1014);
		dma.setName("suja1");
		dma.setShares(75);
		
		SavingsAccount svc=new SavingsAccount();
		svc.setAccNum(1015);
		svc.setName("hari1");
		svc.setInterestRate(8.7f);
		
		
		session.beginTransaction();
		session.save(ac);
		session.save(dma);
		session.save(svc);
		session.getTransaction().commit();
		session.close();
		
	}

}
