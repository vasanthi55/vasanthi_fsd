import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { AdditemComponent } from './additem/additem.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { SellerloginComponent } from './sellerlogin/sellerlogin.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import { LogoutComponent } from './logout/logout.component';

const routes: Routes = [
  {path : 'searchproduct',component:SearchproductComponent},
  {path : 'displaycart' , component:DisplaycartComponent},
  {path : 'buyersignup', component:BuyersignupComponent},
  {path : 'sellersignup', component:SellersignupComponent},
  {path: 'additem', component:AdditemComponent},
  {path:'checkout',component:CheckoutComponent},
  {path:'sellerLogin',component:SellerloginComponent},
  {path:'buyerlogin',component:BuyerloginComponent},
  {path:'logout',component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
