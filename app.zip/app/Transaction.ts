export class Transaction {

    transactionType:String;
    dateTime:String;
 

}