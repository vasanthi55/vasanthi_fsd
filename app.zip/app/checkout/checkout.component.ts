import { Component, OnInit } from '@angular/core';

import { Cart } from '../cart';
import { Transaction } from '../Transaction';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
 

  constructor(private displaycart:ProductService) { }
  transaction:Transaction;
  transactionType:String;
  dateTime:String;
  cart:Cart=new Cart();
  
  ngOnInit(): void {
  }
  Checkout(){
    console.log();
    this.transaction=new Transaction();
    this.transaction.transactionType=this.transactionType;
    this.transaction.dateTime=this.dateTime;
   this.displaycart.CheckoutCart(this.transaction).subscribe(view => this.transaction=view);
   }
}
